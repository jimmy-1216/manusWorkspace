import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import TabBar from "./components/TabBar";
import FeedPage from "./pages/feed/FeedPage";
import ArticlePage from "./pages/article/ArticlePage";
import SearchPage from "./pages/search/SearchPage";
import PreferencePage from "./pages/preference/PreferencePage";
import ProfilePage from "./pages/profile/ProfilePage";
import CollectPage from "./pages/profile/CollectPage";
import HistoryPage from "./pages/profile/HistoryPage";
import RadarPage from "./pages/profile/RadarPage";
import StatsPage from "./pages/profile/StatsPage";
import AccountDeletePage from "./pages/profile/AccountDeletePage";
import OnboardingPage from "./pages/onboarding/OnboardingPage";
import LoginPage from "./pages/login/LoginPage";
import { useUser } from "./stores/useAppStore";
import { useState } from "react";

// 需要显示底部导航的路由
const TAB_ROUTES = ['/feed', '/search', '/preference', '/profile', '/'];

function AppContent() {
  const [location, navigate] = useLocation();
  const { hasOnboarded } = useUser();
  const [showLogin, setShowLogin] = useState(false);
  const showTabBar = TAB_ROUTES.includes(location);

  // 首次使用，显示 Onboarding
  if (!hasOnboarded) {
    return (
      <div className="phone-shell">
        <OnboardingPage onComplete={() => navigate('/feed')} />
      </div>
    );
  }

  // 登录页
  if (showLogin) {
    return (
      <div className="phone-shell">
        <LoginPage onSuccess={() => setShowLogin(false)} />
      </div>
    );
  }

  return (
    <div className="phone-shell">
      <div style={{ minHeight: '100vh', background: '#f5f5f5' }}>
        <Switch>
          <Route path="/" component={FeedPage} />
          <Route path="/feed" component={FeedPage} />
          <Route path="/article/:id" component={ArticlePage} />
          <Route path="/search" component={SearchPage} />
          <Route path="/preference" component={PreferencePage} />
          <Route path="/profile" component={ProfilePage} />
          <Route path="/profile/collect" component={CollectPage} />
          <Route path="/profile/history" component={HistoryPage} />
          <Route path="/profile/radar" component={RadarPage} />
          <Route path="/profile/stats" component={StatsPage} />
          <Route path="/profile/delete-account" component={AccountDeletePage} />
          <Route>
            <div style={{ textAlign: 'center', padding: '80px 20px', color: '#999' }}>
              <div style={{ fontSize: 40 }}>😕</div>
              <div style={{ fontSize: 15, marginTop: 12 }}>页面不存在</div>
            </div>
          </Route>
        </Switch>
        {showTabBar && <TabBar />}
      </div>
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          {/* 桌面端背景 */}
          <div style={{
            minHeight: '100vh',
            background: 'linear-gradient(135deg, #f0faf5 0%, #e8f5e9 50%, #f0f4ff 100%)',
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'center',
            paddingTop: 0,
          }}>
            <AppContent />
          </div>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
