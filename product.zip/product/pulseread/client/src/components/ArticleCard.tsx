import { useLocation } from 'wouter'
import type { Article } from '../types'
import { DOMAIN_CONFIGS } from '../data/mockData'

interface Props {
  article: Article
  radarWords?: string[]
  onLike?: (id: number) => void
  onCollect?: (id: number) => void
  onRead?: (id: number) => void
}

const SENTIMENT_MAP = {
  positive: { label: '利好', className: 'sentiment-positive' },
  negative: { label: '利空', className: 'sentiment-negative' },
  neutral: { label: '中性', className: 'sentiment-neutral' },
}

export default function ArticleCard({ article, radarWords = [], onLike, onCollect, onRead }: Props) {
  const [, navigate] = useLocation()
  const domain = DOMAIN_CONFIGS.find((d) => d.key === article.domain)
  const hitRadar = article.radarWords?.filter((w) => radarWords.includes(w)) ?? []
  const sentiment = SENTIMENT_MAP[article.sentiment]
  const isRead = (article as any).isRead === true

  const scoreColor = article.aiScore >= 88 ? '#FF4D4F' : article.aiScore >= 75 ? '#FA8C16' : article.aiScore >= 60 ? '#00B96B' : '#8C8C8C'

  const handleNavigate = () => {
    onRead?.(article.id)
    navigate(`/article/${article.id}`)
  }

  return (
    <div
      className="article-card"
      style={{ opacity: isRead ? 0.82 : 1, transition: 'opacity 0.2s', position: 'relative' }}
    >
      {/* 已读角标 */}
      {isRead && (
        <div style={{
          position: 'absolute', top: 10, right: 10,
          display: 'inline-flex', alignItems: 'center', gap: 3,
          fontSize: 10, color: '#00B96B', background: '#e8fff4',
          padding: '2px 7px', borderRadius: 8, fontWeight: 500,
        }}>
          ✓ 已读
        </div>
      )}

      {/* 雷达词徽章 */}
      {hitRadar.length > 0 && (
        <div className="radar-badge">
          <span>📡</span>
          <span>{hitRadar.join(' · ')} 命中雷达</span>
        </div>
      )}

      {/* 标题 */}
      <h3
        onClick={handleNavigate}
        style={{
          fontSize: 15, fontWeight: 600, lineHeight: 1.5,
          color: isRead ? '#aaa' : '#1a1a1a',
          marginBottom: 8, cursor: 'pointer',
          paddingRight: isRead ? 52 : 0,
          transition: 'color 0.2s',
        }}
      >
        {article.title}
      </h3>

      {/* 摘要 */}
      <p style={{ fontSize: 13, color: isRead ? '#bbb' : '#666', lineHeight: 1.6, marginBottom: 10, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', transition: 'color 0.2s' }}>
        {article.summary}
      </p>

      {/* 底部信息行 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        {domain && (
          <span className="domain-tag" style={{ background: domain.bgColor, color: domain.color }}>
            {domain.icon} {domain.label}
          </span>
        )}
        <span className={`domain-tag ${sentiment.className}`}>{sentiment.label}</span>
        <span className="ai-score-badge" style={{ background: `${scoreColor}15`, color: scoreColor }}>
          ⚡ {article.aiScore}
        </span>
        <span style={{ fontSize: 11, color: '#bbb', marginLeft: 'auto' }}>
          {article.source} · {article.publishTime}
        </span>
      </div>

      {/* 操作行 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 10, paddingTop: 10, borderTop: '1px solid #f5f5f5' }}>
        <button
          onClick={(e) => { e.preventDefault(); onLike?.(article.id) }}
          style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: article.isLiked ? '#00B96B' : '#999', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
        >
          {article.isLiked ? '👍' : '👍🏻'} {article.likeCount}
        </button>
        <button
          onClick={(e) => { e.preventDefault(); onCollect?.(article.id) }}
          style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: article.isCollected ? '#FA8C16' : '#999', background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
        >
          {article.isCollected ? '⭐' : '☆'} {article.collectCount}
        </button>
        {article.isAiTranslated && (
          <span style={{ fontSize: 11, color: '#1677FF', background: '#E6F4FF', padding: '1px 6px', borderRadius: 4 }}>AI 译</span>
        )}
        <button
          onClick={handleNavigate}
          style={{ marginLeft: 'auto', fontSize: 12, color: '#00B96B', fontWeight: 500, background: 'none', border: 'none', padding: 0, cursor: 'pointer' }}
        >
          AI 提炼 →
        </button>
      </div>
    </div>
  )
}
