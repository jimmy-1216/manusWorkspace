import { useRef } from 'react'
import { NOISE_LEVEL_CONFIGS } from '../data/mockData'
import type { NoiseLevel } from '../types'

interface Props {
  open: boolean
  current: NoiseLevel
  onSelect: (level: NoiseLevel) => void
  onClose: () => void
}

const CARD_COLORS: Record<string, { bg: string; border: string; accent: string; iconBg: string }> = {
  open:  { bg: '#F0F9FF', border: '#BAE0FF', accent: '#1677FF', iconBg: '#E6F4FF' },
  focus: { bg: '#F6FFED', border: '#B7EB8F', accent: '#52C41A', iconBg: '#F6FFED' },
  major: { bg: '#FFF7E6', border: '#FFD591', accent: '#FA8C16', iconBg: '#FFF7E6' },
  quake: { bg: '#FFF1F0', border: '#FFA39E', accent: '#FF4D4F', iconBg: '#FFF1F0' },
}

export default function NoiseLevelSheet({ open, current, onSelect, onClose }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null)

  if (!open) return null

  return (
    <>
      {/* 遮罩 */}
      <div
        onClick={onClose}
        style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 200, backdropFilter: 'blur(2px)' }}
      />

      {/* 底部弹出面板 */}
      <div style={{
        position: 'fixed',
        bottom: 0,
        left: '50%',
        transform: 'translateX(-50%)',
        width: 390,
        background: 'white',
        borderRadius: '20px 20px 0 0',
        padding: '0 0 36px',
        zIndex: 201,
        animation: 'slideUp 0.28s cubic-bezier(0.34, 1.56, 0.64, 1)',
      }}>
        {/* 拖拽条 */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 0' }}>
          <div style={{ width: 36, height: 4, background: '#e0e0e0', borderRadius: 2 }} />
        </div>

        {/* 标题 */}
        <div style={{ padding: '14px 20px 16px', borderBottom: '1px solid #f5f5f5' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a' }}>选择降噪档位</div>
          <div style={{ fontSize: 12, color: '#999', marginTop: 3 }}>
            左右滑动查看全部档位 · AI 评分越高，资讯质量越精
          </div>
        </div>

        {/* 横向滑动卡片区 */}
        <div
          ref={scrollRef}
          style={{
            display: 'flex',
            gap: 12,
            padding: '16px 20px',
            overflowX: 'auto',
            scrollSnapType: 'x mandatory',
            WebkitOverflowScrolling: 'touch',
            scrollbarWidth: 'none',
          }}
        >
          {NOISE_LEVEL_CONFIGS.map((cfg) => {
            const isActive = current === cfg.key
            const colors = CARD_COLORS[cfg.key]
            return (
              <div
                key={cfg.key}
                onClick={() => { onSelect(cfg.key); onClose() }}
                style={{
                  flexShrink: 0,
                  width: 148,
                  scrollSnapAlign: 'start',
                  borderRadius: 16,
                  border: `2px solid ${isActive ? colors.accent : colors.border}`,
                  background: colors.bg,
                  padding: '16px 14px',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  position: 'relative',
                  boxShadow: isActive ? `0 4px 16px ${colors.accent}30` : '0 2px 8px rgba(0,0,0,0.04)',
                  transform: isActive ? 'translateY(-2px)' : 'none',
                }}
              >
                {/* 推荐标签 */}
                {cfg.recommended && (
                  <div style={{
                    position: 'absolute', top: -1, right: -1,
                    background: colors.accent, color: 'white',
                    fontSize: 10, fontWeight: 700, padding: '2px 8px',
                    borderRadius: '0 14px 0 8px',
                  }}>推荐</div>
                )}

                {/* 图标 */}
                <div style={{
                  width: 44, height: 44, borderRadius: 12,
                  background: 'white',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 22, marginBottom: 12,
                  boxShadow: `0 2px 8px ${colors.accent}20`,
                }}>
                  {cfg.icon}
                </div>

                {/* 名称 */}
                <div style={{ fontSize: 14, fontWeight: 700, color: isActive ? colors.accent : '#1a1a1a', marginBottom: 4 }}>
                  {cfg.label}
                </div>

                {/* 描述 */}
                <div style={{ fontSize: 11, color: '#888', lineHeight: 1.5, marginBottom: 10 }}>
                  {cfg.description}
                </div>

                {/* 每日数量 */}
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 4,
                  background: 'white', borderRadius: 20, padding: '3px 10px',
                  fontSize: 11, color: colors.accent, fontWeight: 600,
                }}>
                  {cfg.dailyCount}
                </div>

                {/* 选中勾 */}
                {isActive && (
                  <div style={{
                    position: 'absolute', bottom: 12, right: 12,
                    width: 22, height: 22, borderRadius: '50%',
                    background: colors.accent, color: 'white',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 13, fontWeight: 700,
                  }}>✓</div>
                )}
              </div>
            )
          })}
        </div>

        {/* 分数轴 */}
        <div style={{ padding: '0 20px', marginTop: -4 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
            {NOISE_LEVEL_CONFIGS.map((cfg) => (
              <div key={cfg.key} style={{ textAlign: 'center', flex: 1 }}>
                <div style={{
                  width: 8, height: 8, borderRadius: '50%', margin: '0 auto 3px',
                  background: current === cfg.key ? CARD_COLORS[cfg.key].accent : '#e0e0e0',
                  transition: 'background 0.2s',
                }} />
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', background: '#f5f5f5', borderRadius: 8, overflow: 'hidden', height: 4 }}>
            {NOISE_LEVEL_CONFIGS.map((cfg, i) => (
              <div key={cfg.key} style={{
                flex: 1,
                background: ['open','focus','major','quake'].indexOf(current) >= i
                  ? CARD_COLORS[cfg.key].accent : 'transparent',
                transition: 'background 0.2s',
              }} />
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
            <span style={{ fontSize: 10, color: '#bbb' }}>全量</span>
            <span style={{ fontSize: 10, color: '#bbb' }}>精华</span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideUp {
          from { transform: translateX(-50%) translateY(100%); }
          to { transform: translateX(-50%) translateY(0); }
        }
        div::-webkit-scrollbar { display: none; }
      `}</style>
    </>
  )
}
