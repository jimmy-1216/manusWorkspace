import { useLocation } from 'wouter'

const tabs = [
  { path: '/feed', icon: '🏠', label: '发现' },
  { path: '/search', icon: '🔍', label: '搜索' },
  { path: '/preference', icon: '🎛️', label: '偏好' },
  { path: '/profile', icon: '👤', label: '我的' },
]

export default function TabBar() {
  const [location, navigate] = useLocation()

  return (
    <div style={{
      position: 'fixed',
      bottom: 0,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 390,
      background: 'white',
      borderTop: '1px solid #f0f0f0',
      display: 'flex',
      alignItems: 'stretch',
      zIndex: 1000,
      boxShadow: '0 -2px 12px rgba(0,0,0,0.06)',
    }}>
      {tabs.map((tab) => {
        const active = location === tab.path || (tab.path === '/feed' && (location === '/' || location === ''))
        return (
          <button
            key={tab.path}
            onClick={() => navigate(tab.path)}
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '8px 0 10px',
              gap: 3,
              border: 'none',
              background: 'none',
              cursor: 'pointer',
              color: active ? '#00B96B' : '#999',
              transition: 'color 0.2s',
            }}
          >
            <span style={{ fontSize: 22, lineHeight: 1 }}>{tab.icon}</span>
            <span style={{ fontSize: 11, fontWeight: active ? 600 : 400, lineHeight: 1 }}>{tab.label}</span>
          </button>
        )
      })}
    </div>
  )
}
