import { useState, useEffect } from 'react'
import { useParams, useLocation } from 'wouter'
import { useArticle } from '../../stores/useAppStore'
import { DOMAIN_CONFIGS, QUICK_QUESTIONS } from '../../data/mockData'

type TabType = 'ai' | 'original' | 'bilingual'

export default function ArticlePage() {
  const params = useParams<{ id: string }>()
  const [, navigate] = useLocation()
  const id = Number(params.id)
  const { article, toggleLike, toggleCollect, markRead } = useArticle(id)
  const [activeTab, setActiveTab] = useState<TabType>('ai')

  // 进入文章时自动标记已读
  useEffect(() => { markRead() }, [id])
  const [chatInput, setChatInput] = useState('')
  const [chatMessages, setChatMessages] = useState<{ role: 'user' | 'ai'; text: string }[]>([])

  if (!article) {
    return (
      <div style={{ textAlign: 'center', padding: '80px 20px', color: '#999' }}>
        <div style={{ fontSize: 40 }}>😕</div>
        <div style={{ fontSize: 15, marginTop: 12 }}>文章不存在</div>
        <button onClick={() => navigate('/feed')} style={{ marginTop: 16, color: '#00B96B', background: 'none', border: 'none', fontSize: 14 }}>返回发现页</button>
      </div>
    )
  }

  const domain = DOMAIN_CONFIGS.find((d) => d.key === article.domain)
  const questions = QUICK_QUESTIONS[article.domain] ?? QUICK_QUESTIONS.default

  const handleSendChat = (text: string) => {
    if (!text.trim()) return
    setChatMessages((prev) => [
      ...prev,
      { role: 'user', text },
      { role: 'ai', text: `正在分析「${article.title}」相关内容...\n\n根据文章内容，${text}的核心要点是：这是一个模拟的 AI 回答，实际接入后端后将由大模型实时生成。` },
    ])
    setChatInput('')
  }

  const scoreColor = article.aiScore >= 88 ? '#FF4D4F' : article.aiScore >= 75 ? '#FA8C16' : '#00B96B'

  return (
    <div style={{ background: '#f5f5f5', minHeight: '100vh', paddingBottom: 80 }}>
      {/* 顶部导航 */}
      <div style={{ background: 'white', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, zIndex: 50 }}>
        <button onClick={() => navigate('/feed')} style={{ background: 'none', border: 'none', fontSize: 20, padding: 0, color: '#333' }}>←</button>
        <span style={{ fontSize: 15, fontWeight: 600, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>文章详情</span>
        <button style={{ background: 'none', border: 'none', fontSize: 18, padding: 0 }}>⋯</button>
      </div>

      {/* 文章头部 */}
      <div style={{ background: 'white', padding: '16px', marginBottom: 8 }}>
        {/* 领域 & 评分 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
          {domain && (
            <span className="domain-tag" style={{ background: domain.bgColor, color: domain.color }}>
              {domain.icon} {domain.label}
            </span>
          )}
          <span style={{ fontSize: 11, background: `${scoreColor}15`, color: scoreColor, padding: '2px 8px', borderRadius: 10, fontWeight: 600 }}>
            ⚡ AI {article.aiScore}
          </span>
          {article.isAiTranslated && (
            <span style={{ fontSize: 11, background: '#E6F4FF', color: '#1677FF', padding: '2px 8px', borderRadius: 10 }}>AI 译</span>
          )}
        </div>

        <h1 style={{ fontSize: 18, fontWeight: 700, lineHeight: 1.5, color: '#1a1a1a', marginBottom: 10 }}>{article.title}</h1>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#999' }}>
          <span>{article.source}</span>
          <span>·</span>
          <span>{article.publishTime}</span>
        </div>

        {/* 操作按钮 */}
        <div style={{ display: 'flex', gap: 16, marginTop: 12, paddingTop: 12, borderTop: '1px solid #f5f5f5' }}>
          <button
            onClick={toggleLike}
            style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: article.isLiked ? '#00B96B' : '#999', background: 'none', border: 'none', padding: 0 }}
          >
            {article.isLiked ? '👍' : '👍🏻'} {article.likeCount}
          </button>
          <button
            onClick={toggleCollect}
            style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: article.isCollected ? '#FA8C16' : '#999', background: 'none', border: 'none', padding: 0 }}
          >
            {article.isCollected ? '⭐' : '☆'} {article.collectCount}
          </button>
          <button
            onClick={() => {
              if (navigator.share) {
                navigator.share({ title: article.title, text: article.aiSummary || article.summary, url: window.location.href })
              } else {
                navigator.clipboard.writeText(window.location.href)
                alert('链接已复制到剪贴板')
              }
            }}
            style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: '#999', background: 'none', border: 'none', padding: 0, marginLeft: 'auto' }}
          >
            📤 分享
          </button>
        </div>
      </div>

      {/* Tab 切换 */}
      <div style={{ background: 'white', display: 'flex', borderBottom: '1px solid #f0f0f0', marginBottom: 8, position: 'sticky', top: 53, zIndex: 40 }}>
        {[
          { key: 'ai', label: '🤖 AI 提炼' },
          { key: 'original', label: '📄 原文' },
          { key: 'bilingual', label: '🌐 双语' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as TabType)}
            style={{
              flex: 1,
              padding: '12px 0',
              border: 'none',
              background: 'none',
              fontSize: 13,
              fontWeight: activeTab === tab.key ? 700 : 400,
              color: activeTab === tab.key ? '#00B96B' : '#999',
              borderBottom: activeTab === tab.key ? '2px solid #00B96B' : '2px solid transparent',
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* 免责声明 */}
      {(article.domain === 'finance' || article.domain === 'policy' || article.domain === 'commerce') && (
        <div style={{ margin: '0 12px 8px', padding: '10px 14px', background: article.domain === 'finance' ? '#FFF7E6' : article.domain === 'policy' ? '#E6F4FF' : '#F9F0FF', borderRadius: 10, fontSize: 12, lineHeight: 1.6, color: article.domain === 'finance' ? '#D48806' : article.domain === 'policy' ? '#1677FF' : '#722ED1' }}>
          ⚠️ {article.domain === 'finance' ? '免责声明：本文内容仅供参考，不构成任何投资建议。投资有风险，入市需谨慎。' : article.domain === 'policy' ? '声明：本文为政策资讯摘要，具体条款请以官方发布为准。' : '声明：本文为商业资讯，不代表平台立场，请独立判断。'}
        </div>
      )}

      {/* Tab 内容 */}
      <div style={{ padding: '0 12px' }}>
        {activeTab === 'ai' && (
          <div>
            {/* AI 摘要 */}
            <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }}>
                <span style={{ fontSize: 16 }}>🤖</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>AI 一句话总结</span>
              </div>
              <p style={{ fontSize: 14, lineHeight: 1.7, color: '#333', background: '#f8fff8', padding: 12, borderRadius: 8, borderLeft: '3px solid #00B96B' }}>
                {article.aiSummary || article.summary}
              </p>
            </div>

            {/* AI 要点 */}
            {article.aiKeyPoints && article.aiKeyPoints.length > 0 && (
              <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }}>
                  <span style={{ fontSize: 16 }}>📌</span>
                  <span style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>核心要点</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {article.aiKeyPoints.map((point, i) => (
                    <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                      <span style={{ minWidth: 20, height: 20, background: '#00B96B', color: 'white', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, flexShrink: 0 }}>{i + 1}</span>
                      <span style={{ fontSize: 13, lineHeight: 1.6, color: '#333' }}>{point}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 知识溯源树 */}
            {article.knowledgeTree && article.knowledgeTree.length > 0 && (
              <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 8 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }}>
                  <span style={{ fontSize: 16 }}>🌳</span>
                  <span style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>知识溯源树</span>
                </div>
                {article.knowledgeTree.map((node) => (
                  <div key={node.id}>
                    <div style={{ padding: '8px 12px', background: '#f0faf5', borderRadius: 8, marginBottom: 6 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: '#00B96B' }}>{node.title}</div>
                      <div style={{ fontSize: 12, color: '#666', marginTop: 2 }}>{node.description}</div>
                    </div>
                    {node.children?.map((child) => (
                      <div key={child.id} style={{ marginLeft: 20, padding: '6px 12px', background: '#fafafa', borderRadius: 8, marginBottom: 4, borderLeft: '2px solid #00B96B' }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: '#333' }}>{child.title}</div>
                        <div style={{ fontSize: 11, color: '#999', marginTop: 1 }}>{child.description}</div>
                        {child.date && <div style={{ fontSize: 10, color: '#bbb', marginTop: 1 }}>{child.date}</div>}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}

            {/* 快捷提问 */}
            <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12 }}>
                <span style={{ fontSize: 16 }}>💬</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>快捷提问</span>
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {questions.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => handleSendChat(q)}
                    style={{
                      padding: '6px 12px',
                      borderRadius: 20,
                      border: '1px solid #e0f5ea',
                      background: '#f8fff8',
                      color: '#00B96B',
                      fontSize: 12,
                      cursor: 'pointer',
                    }}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            {/* AI 对话 */}
            {chatMessages.length > 0 && (
              <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 8 }}>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {chatMessages.map((msg, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                      <div style={{
                        maxWidth: '80%',
                        padding: '8px 12px',
                        borderRadius: msg.role === 'user' ? '12px 12px 2px 12px' : '12px 12px 12px 2px',
                        background: msg.role === 'user' ? '#00B96B' : '#f5f5f5',
                        color: msg.role === 'user' ? 'white' : '#333',
                        fontSize: 13,
                        lineHeight: 1.6,
                        whiteSpace: 'pre-wrap',
                      }}>
                        {msg.text}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 输入框 */}
            <div style={{ background: 'white', borderRadius: 12, padding: '10px 12px', display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
              <input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendChat(chatInput)}
                placeholder="继续追问 AI..."
                style={{ flex: 1, border: 'none', outline: 'none', fontSize: 13, color: '#333', background: 'transparent' }}
              />
              <button
                onClick={() => handleSendChat(chatInput)}
                style={{ background: '#00B96B', color: 'white', border: 'none', borderRadius: 20, padding: '6px 14px', fontSize: 13, cursor: 'pointer' }}
              >
                发送
              </button>
            </div>
          </div>
        )}

        {activeTab === 'original' && (
          <div style={{ background: 'white', borderRadius: 12, padding: 16 }}>
            <p style={{ fontSize: 14, lineHeight: 1.8, color: '#333', whiteSpace: 'pre-wrap' }}>
              {article.content || article.summary}
            </p>
          </div>
        )}

        {activeTab === 'bilingual' && (
          <div>
            <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 8 }}>
              <div style={{ fontSize: 12, color: '#00B96B', fontWeight: 600, marginBottom: 8 }}>🇨🇳 中文</div>
              <p style={{ fontSize: 14, lineHeight: 1.8, color: '#333' }}>{article.content || article.summary}</p>
            </div>
            {article.contentEn && (
              <div style={{ background: 'white', borderRadius: 12, padding: 16 }}>
                <div style={{ fontSize: 12, color: '#1677FF', fontWeight: 600, marginBottom: 8 }}>🇺🇸 English</div>
                <p style={{ fontSize: 14, lineHeight: 1.8, color: '#333' }}>{article.contentEn}</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
