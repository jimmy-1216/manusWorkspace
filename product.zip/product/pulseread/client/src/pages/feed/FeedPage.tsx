import { useState, useMemo } from 'react'
import { useFeed, usePreference, useUser } from '../../stores/useAppStore'
import { DOMAIN_CONFIGS, NOISE_LEVEL_CONFIGS } from '../../data/mockData'
import ArticleCard from '../../components/ArticleCard'
import NoiseLevelSheet from '../../components/NoiseLevelSheet'
import type { DomainType, RegionType } from '../../types'

// 广告卡片数据
const AD_CARDS = [
  { id: 'ad-1', title: '升级 Pro，解锁无限资讯', desc: '无限阅读 · 无广告 · 数据导出 · 无限雷达词', cta: '立即升级 ¥99/月', color: '#FA8C16', bg: 'linear-gradient(135deg, #FFF7E6 0%, #FFE7BA 100%)' },
  { id: 'ad-2', title: '企业版限时优惠', desc: 'API 接入 · 团队管理 · 定制报告 · 专属客服', cta: '了解详情', color: '#722ED1', bg: 'linear-gradient(135deg, #F9F0FF 0%, #EFDBFF 100%)' },
]

export default function FeedPage() {
  const [region, setRegion] = useState<RegionType>('all')
  const [domain, setDomain] = useState<DomainType | 'all'>('all')
  const [noiseOpen, setNoiseOpen] = useState(false)
  const { pref, setNoiseLevel } = usePreference()
  const { user } = useUser()
  const { articles, toggleLike, toggleCollect, markRead } = useFeed(domain, region)

  const currentNoise = NOISE_LEVEL_CONFIGS.find((n) => n.key === pref.noiseLevel)!

  // 应用情绪过滤
  const filteredArticles = useMemo(() => {
    const blocked = pref.blockedSentiments || []
    if (blocked.length === 0) return articles
    return articles.filter((a) => !blocked.includes(a.sentiment))
  }, [articles, pref.blockedSentiments])

  // 构建含广告的列表（Free 用户每 5 条插入 1 条广告）
  const feedItems = useMemo(() => {
    if (user.plan !== 'free') return filteredArticles.map((a) => ({ type: 'article' as const, data: a }))
    const items: Array<{ type: 'article'; data: typeof filteredArticles[0] } | { type: 'ad'; data: typeof AD_CARDS[0] }> = []
    filteredArticles.forEach((a, i) => {
      items.push({ type: 'article', data: a })
      // 每 5 条文章后插入一个广告
      if ((i + 1) % 5 === 0 && user.plan === 'free') {
        const adIndex = Math.floor(i / 5) % AD_CARDS.length
        items.push({ type: 'ad', data: AD_CARDS[adIndex] })
      }
    })
    return items
  }, [filteredArticles, user.plan])

  return (
    <div style={{ paddingBottom: 70 }}>
      {/* 顶部导航 */}
      <div className="top-nav">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 20, fontWeight: 800, color: '#00B96B' }}>微澜</span>
            <span style={{ fontSize: 11, background: '#e8fff4', color: '#00B96B', padding: '1px 6px', borderRadius: 8 }}>PulseRead</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{ background: 'none', border: 'none', fontSize: 20, padding: 0 }}>🔔</button>
          </div>
        </div>

        {/* 地区 + 领域 合并为一行下划线 Tab */}
        <div style={{
          display: 'flex',
          gap: 0,
          overflowX: 'auto',
          scrollbarWidth: 'none',
          marginTop: 4,
          borderBottom: '1px solid #f0f0f0',
        }}>
          {/* 地区组 */}
          {(['all', 'domestic', 'international'] as const).map((r) => {
            const labels = { all: '全部', domestic: '国内', international: '国外' }
            const isActive = region === r && domain === 'all'
            return (
              <button
                key={r}
                onClick={() => { setRegion(r); setDomain('all') }}
                style={{
                  flexShrink: 0,
                  padding: '8px 14px 9px',
                  border: 'none',
                  background: 'none',
                  fontSize: 13,
                  fontWeight: isActive ? 700 : 400,
                  color: isActive ? '#00B96B' : '#888',
                  cursor: 'pointer',
                  borderBottom: isActive ? '2.5px solid #00B96B' : '2.5px solid transparent',
                  marginBottom: -1,
                  transition: 'all 0.18s',
                  whiteSpace: 'nowrap',
                }}
              >
                {labels[r]}
              </button>
            )
          })}

          {/* 分隔线 */}
          <div style={{ width: 1, height: 16, background: '#e8e8e8', alignSelf: 'center', margin: '0 4px', flexShrink: 0 }} />

          {/* 领域组 */}
          {DOMAIN_CONFIGS.map((d) => {
            const isActive = domain === d.key
            return (
              <button
                key={d.key}
                onClick={() => { setDomain(isActive ? 'all' : d.key); setRegion('all') }}
                style={{
                  flexShrink: 0,
                  padding: '8px 14px 9px',
                  border: 'none',
                  background: 'none',
                  fontSize: 13,
                  fontWeight: isActive ? 700 : 400,
                  color: isActive ? d.color : '#888',
                  cursor: 'pointer',
                  borderBottom: isActive ? `2.5px solid ${d.color}` : '2.5px solid transparent',
                  marginBottom: -1,
                  transition: 'all 0.18s',
                  whiteSpace: 'nowrap',
                }}
              >
                {d.icon} {d.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* 降噪档位条 */}
      <div
        onClick={() => setNoiseOpen(true)}
        style={{
          margin: '8px 12px',
          padding: '10px 14px',
          background: 'white',
          borderRadius: 12,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
          boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 18 }}>{currentNoise.icon}</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#00B96B' }}>{currentNoise.label}</div>
            <div style={{ fontSize: 11, color: '#999' }}>{currentNoise.description} · {currentNoise.dailyCount}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <span style={{ fontSize: 12, color: '#999' }}>切换</span>
          <span style={{ color: '#ccc' }}>›</span>
        </div>
      </div>

      {/* 资讯列表 */}
      <div style={{ padding: '0 12px' }}>
        {feedItems.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#999' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🔇</div>
            <div style={{ fontSize: 15, fontWeight: 500 }}>当前档位过滤后暂无资讯</div>
            <div style={{ fontSize: 13, marginTop: 6 }}>尝试降低降噪档位或切换领域</div>
          </div>
        ) : (
          feedItems.map((item, idx) => {
            if (item.type === 'ad') {
              const ad = item.data as typeof AD_CARDS[0]
              return (
                <div
                  key={ad.id + '-' + idx}
                  style={{
                    background: ad.bg,
                    borderRadius: 12,
                    padding: '16px',
                    marginBottom: 10,
                    position: 'relative',
                    overflow: 'hidden',
                  }}
                >
                  <div style={{ position: 'absolute', top: 8, right: 10, fontSize: 10, color: '#bbb', background: 'rgba(255,255,255,0.6)', padding: '1px 6px', borderRadius: 8 }}>广告</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: ad.color, marginBottom: 6 }}>{ad.title}</div>
                  <div style={{ fontSize: 12, color: '#666', marginBottom: 12, lineHeight: 1.5 }}>{ad.desc}</div>
                  <button style={{
                    background: ad.color,
                    color: 'white',
                    border: 'none',
                    borderRadius: 20,
                    padding: '6px 18px',
                    fontSize: 12,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}>
                    {ad.cta}
                  </button>
                </div>
              )
            }
            const article = item.data as typeof filteredArticles[0]
            return (
              <ArticleCard
                key={article.id}
                article={article}
                radarWords={pref.radarWords}
                onLike={toggleLike}
                onCollect={toggleCollect}
                onRead={markRead}
              />
            )
          })
        )}
      </div>

      {/* 降噪选择器 */}
      <NoiseLevelSheet
        open={noiseOpen}
        current={pref.noiseLevel}
        onSelect={setNoiseLevel}
        onClose={() => setNoiseOpen(false)}
      />
    </div>
  )
}
