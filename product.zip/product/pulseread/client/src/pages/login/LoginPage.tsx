import { useState } from 'react'
import { useUser } from '../../stores/useAppStore'

interface Props {
  onSuccess: () => void
}

export default function LoginPage({ onSuccess }: Props) {
  const [mode, setMode] = useState<'wechat' | 'phone'>('wechat')
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [countdown, setCountdown] = useState(0)
  const { login } = useUser()

  const sendCode = () => {
    if (!phone || phone.length !== 11) return
    setCountdown(60)
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) { clearInterval(timer); return 0 }
        return prev - 1
      })
    }, 1000)
  }

  const handleLogin = () => {
    login('微澜用户')
    onSuccess()
  }

  return (
    <div style={{ minHeight: '100vh', background: 'white', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '60px 24px 40px' }}>
      {/* Logo */}
      <div style={{ textAlign: 'center', marginBottom: 48 }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>🌊</div>
        <div style={{ fontSize: 28, fontWeight: 800, color: '#00B96B' }}>微澜</div>
        <div style={{ fontSize: 13, color: '#999', marginTop: 4 }}>AI 驱动的跨领域资讯聚合平台</div>
      </div>

      {/* Tab 切换 */}
      <div style={{ display: 'flex', background: '#f5f5f5', borderRadius: 12, padding: 4, marginBottom: 28, width: '100%', maxWidth: 340 }}>
        <button
          onClick={() => setMode('wechat')}
          style={{
            flex: 1, padding: '10px', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer',
            background: mode === 'wechat' ? 'white' : 'transparent',
            color: mode === 'wechat' ? '#1a1a1a' : '#999',
            boxShadow: mode === 'wechat' ? '0 1px 4px rgba(0,0,0,0.1)' : 'none',
            transition: 'all 0.2s',
          }}
        >
          微信登录
        </button>
        <button
          onClick={() => setMode('phone')}
          style={{
            flex: 1, padding: '10px', border: 'none', borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: 'pointer',
            background: mode === 'phone' ? 'white' : 'transparent',
            color: mode === 'phone' ? '#1a1a1a' : '#999',
            boxShadow: mode === 'phone' ? '0 1px 4px rgba(0,0,0,0.1)' : 'none',
            transition: 'all 0.2s',
          }}
        >
          手机号登录
        </button>
      </div>

      <div style={{ width: '100%', maxWidth: 340 }}>
        {mode === 'wechat' ? (
          <div style={{ textAlign: 'center' }}>
            <div style={{ width: 120, height: 120, background: '#f5f5f5', borderRadius: 16, margin: '0 auto 20px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 48 }}>
              💬
            </div>
            <div style={{ fontSize: 14, color: '#666', marginBottom: 24, lineHeight: 1.6 }}>
              使用微信扫码或点击下方按钮<br />快速登录微澜
            </div>
            <button
              onClick={handleLogin}
              style={{ width: '100%', padding: '14px', background: '#07C160', color: 'white', border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
            >
              <span style={{ fontSize: 20 }}>💬</span> 微信一键登录
            </button>
          </div>
        ) : (
          <div>
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 13, color: '#666', marginBottom: 6 }}>手机号</div>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="请输入手机号"
                maxLength={11}
                style={{ width: '100%', padding: '12px 14px', border: '1px solid #e0e0e0', borderRadius: 10, fontSize: 15, outline: 'none', boxSizing: 'border-box' }}
              />
            </div>
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 13, color: '#666', marginBottom: 6 }}>验证码</div>
              <div style={{ display: 'flex', gap: 10 }}>
                <input
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="请输入验证码"
                  maxLength={6}
                  style={{ flex: 1, padding: '12px 14px', border: '1px solid #e0e0e0', borderRadius: 10, fontSize: 15, outline: 'none' }}
                />
                <button
                  onClick={sendCode}
                  disabled={countdown > 0 || phone.length !== 11}
                  style={{
                    padding: '12px 14px', border: 'none', borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap',
                    background: countdown > 0 || phone.length !== 11 ? '#f0f0f0' : '#e8fff4',
                    color: countdown > 0 || phone.length !== 11 ? '#999' : '#00B96B',
                  }}
                >
                  {countdown > 0 ? `${countdown}s` : '获取验证码'}
                </button>
              </div>
            </div>
            <button
              onClick={handleLogin}
              style={{ width: '100%', padding: '14px', background: '#00B96B', color: 'white', border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
            >
              登录
            </button>
          </div>
        )}
      </div>

      <div style={{ marginTop: 32, fontSize: 12, color: '#bbb', textAlign: 'center' }}>
        登录即代表同意《用户协议》和《隐私政策》
      </div>
    </div>
  )
}
