import { useState } from 'react'
import { useUser, usePreference } from '../../stores/useAppStore'
import { DOMAIN_CONFIGS, NOISE_LEVEL_CONFIGS, SUGGESTED_RADAR_WORDS } from '../../data/mockData'
import type { DomainType, NoiseLevel } from '../../types'

interface Props {
  onComplete: () => void
}

export default function OnboardingPage({ onComplete }: Props) {
  const [step, setStep] = useState(1)
  const [selectedDomains, setSelectedDomains] = useState<DomainType[]>(['tech', 'finance'])
  const [selectedNoise, setSelectedNoise] = useState<NoiseLevel>('focus')
  const [selectedRadar, setSelectedRadar] = useState<string[]>([])
  const { completeOnboarding } = useUser()
  const { setNoiseLevel, toggleDomain, addRadarWord } = usePreference()

  const toggleDomainLocal = (key: DomainType) => {
    setSelectedDomains((prev) =>
      prev.includes(key) ? prev.filter((d) => d !== key) : [...prev, key]
    )
  }

  const toggleRadar = (word: string) => {
    setSelectedRadar((prev) =>
      prev.includes(word) ? prev.filter((w) => w !== word) : [...prev, word]
    )
  }

  const handleComplete = () => {
    // 同步到全局状态
    selectedDomains.forEach((d) => toggleDomain(d))
    setNoiseLevel(selectedNoise)
    selectedRadar.forEach((w) => addRadarWord(w))
    completeOnboarding()
    onComplete()
  }

  return (
    <div style={{ minHeight: '100vh', background: 'white', display: 'flex', flexDirection: 'column' }}>
      {/* 进度条 */}
      <div style={{ padding: '16px 24px 0' }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 24 }}>
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              style={{
                flex: 1, height: 4, borderRadius: 2,
                background: s <= step ? '#00B96B' : '#f0f0f0',
                transition: 'background 0.3s',
              }}
            />
          ))}
        </div>
      </div>

      <div style={{ flex: 1, padding: '0 24px', overflowY: 'auto' }}>
        {step === 1 && (
          <div>
            <div style={{ marginBottom: 28 }}>
              <div style={{ fontSize: 26, fontWeight: 800, color: '#1a1a1a', marginBottom: 8 }}>
                👋 欢迎使用微澜
              </div>
              <div style={{ fontSize: 15, color: '#666', lineHeight: 1.6 }}>
                AI 驱动的跨领域资讯聚合平台，帮你在信息爆炸时代快速获取高价值洞察
              </div>
            </div>

            <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 14 }}>
              选择你关注的领域（可多选）
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {DOMAIN_CONFIGS.map((d) => {
                const selected = selectedDomains.includes(d.key)
                return (
                  <div
                    key={d.key}
                    onClick={() => toggleDomainLocal(d.key)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      padding: '14px 16px',
                      borderRadius: 12,
                      border: `2px solid ${selected ? d.color : '#f0f0f0'}`,
                      background: selected ? d.bgColor : '#fafafa',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                  >
                    <span style={{ fontSize: 26, marginRight: 14 }}>{d.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 15, fontWeight: 600, color: selected ? d.color : '#1a1a1a' }}>{d.label}</div>
                      <div style={{ fontSize: 12, color: '#999', marginTop: 2 }}>{d.description}</div>
                    </div>
                    <div style={{
                      width: 24, height: 24, borderRadius: '50%',
                      background: selected ? d.color : '#f0f0f0',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      color: 'white', fontSize: 14,
                    }}>
                      {selected ? '✓' : ''}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <div style={{ marginBottom: 28 }}>
              <div style={{ fontSize: 24, fontWeight: 800, color: '#1a1a1a', marginBottom: 8 }}>🎛️ 设置降噪档位</div>
              <div style={{ fontSize: 14, color: '#666', lineHeight: 1.6 }}>AI 评分越高，资讯质量越高，数量越少</div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {NOISE_LEVEL_CONFIGS.map((cfg) => {
                const isActive = selectedNoise === cfg.key
                return (
                  <div
                    key={cfg.key}
                    onClick={() => setSelectedNoise(cfg.key)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      padding: '16px',
                      borderRadius: 12,
                      border: `2px solid ${isActive ? '#00B96B' : '#f0f0f0'}`,
                      background: isActive ? '#e8fff4' : '#fafafa',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                  >
                    <span style={{ fontSize: 26, marginRight: 14 }}>{cfg.icon}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: 15, fontWeight: 600, color: isActive ? '#00B96B' : '#1a1a1a' }}>{cfg.label}</span>
                        {cfg.recommended && <span style={{ fontSize: 10, background: '#00B96B', color: 'white', padding: '1px 6px', borderRadius: 8 }}>推荐</span>}
                      </div>
                      <div style={{ fontSize: 12, color: '#999', marginTop: 2 }}>{cfg.description}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 12, color: '#00B96B', fontWeight: 500 }}>{cfg.dailyCount}</div>
                      {isActive && <span style={{ color: '#00B96B', fontSize: 18 }}>✓</span>}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <div style={{ marginBottom: 28 }}>
              <div style={{ fontSize: 24, fontWeight: 800, color: '#1a1a1a', marginBottom: 8 }}>📡 添加专属雷达词</div>
              <div style={{ fontSize: 14, color: '#666', lineHeight: 1.6 }}>命中即强制置顶，穿透所有降噪档位（可跳过）</div>
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {SUGGESTED_RADAR_WORDS.map((word) => {
                const selected = selectedRadar.includes(word)
                return (
                  <button
                    key={word}
                    onClick={() => toggleRadar(word)}
                    style={{
                      padding: '8px 16px',
                      borderRadius: 20,
                      border: `1.5px solid ${selected ? '#00B96B' : '#e0e0e0'}`,
                      background: selected ? '#e8fff4' : 'white',
                      color: selected ? '#00B96B' : '#333',
                      fontSize: 14,
                      fontWeight: selected ? 600 : 400,
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                  >
                    {selected ? '✓ ' : ''}{word}
                  </button>
                )
              })}
            </div>

            {selectedRadar.length > 0 && (
              <div style={{ marginTop: 20, padding: 14, background: '#e8fff4', borderRadius: 10 }}>
                <div style={{ fontSize: 12, color: '#00B96B', fontWeight: 600, marginBottom: 6 }}>已选 {selectedRadar.length} 个雷达词：</div>
                <div style={{ fontSize: 13, color: '#333' }}>{selectedRadar.join('、')}</div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 底部按钮 */}
      <div style={{ padding: '16px 24px', paddingBottom: 32 }}>
        {step < 3 ? (
          <button
            onClick={() => setStep(step + 1)}
            disabled={step === 1 && selectedDomains.length === 0}
            style={{
              width: '100%',
              padding: '14px',
              background: step === 1 && selectedDomains.length === 0 ? '#f0f0f0' : '#00B96B',
              color: step === 1 && selectedDomains.length === 0 ? '#999' : 'white',
              border: 'none',
              borderRadius: 12,
              fontSize: 16,
              fontWeight: 600,
              cursor: step === 1 && selectedDomains.length === 0 ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s',
            }}
          >
            下一步
          </button>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <button
              onClick={handleComplete}
              style={{ width: '100%', padding: '14px', background: '#00B96B', color: 'white', border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
            >
              🚀 开始使用微澜
            </button>
            <button
              onClick={handleComplete}
              style={{ width: '100%', padding: '12px', background: 'none', color: '#999', border: 'none', fontSize: 14, cursor: 'pointer' }}
            >
              跳过
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
