import { useState } from 'react'
import { usePreference } from '../../stores/useAppStore'
import { DOMAIN_CONFIGS, NOISE_LEVEL_CONFIGS, SUGGESTED_RADAR_WORDS } from '../../data/mockData'
import NoiseLevelSheet from '../../components/NoiseLevelSheet'
import type { RegionType } from '../../types'

const SENTIMENT_OPTIONS = [
  { key: 'negative', label: '负面情绪', icon: '😟', desc: '过滤带有负面倾向的资讯', color: '#FF4D4F' },
  { key: 'positive', label: '正面情绪', icon: '😊', desc: '过滤带有正面倾向的资讯', color: '#52C41A' },
  { key: 'neutral', label: '中性情绪', icon: '😐', desc: '过滤中性客观的资讯', color: '#8C8C8C' },
]

const REGION_OPTIONS: { key: RegionType; label: string; icon: string; desc: string }[] = [
  { key: 'all', label: '全部地区', icon: '🌍', desc: '国内外资讯不限' },
  { key: 'domestic', label: '仅国内', icon: '🇨🇳', desc: '只看国内相关资讯' },
  { key: 'international', label: '仅国际', icon: '🌐', desc: '只看国际相关资讯' },
]

export default function PreferencePage() {
  const { pref, setNoiseLevel, toggleDomain, addRadarWord, removeRadarWord, setRegionPref, toggleBlockedSentiment } = usePreference()
  const [noiseOpen, setNoiseOpen] = useState(false)
  const [radarInput, setRadarInput] = useState('')

  const currentNoise = NOISE_LEVEL_CONFIGS.find((n) => n.key === pref.noiseLevel)!

  const handleAddRadar = () => {
    if (radarInput.trim()) {
      addRadarWord(radarInput.trim())
      setRadarInput('')
    }
  }

  return (
    <div style={{ paddingBottom: 70 }}>
      {/* 顶部 */}
      <div className="top-nav">
        <div style={{ fontSize: 18, fontWeight: 700, color: '#1a1a1a' }}>偏好设置</div>
        <div style={{ fontSize: 12, color: '#999', marginTop: 2 }}>个性化你的资讯体验</div>
      </div>

      <div style={{ padding: '12px' }}>
        {/* 降噪档位 */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>🎛️ 降噪档位</div>
          <div
            onClick={() => setNoiseOpen(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '12px 14px',
              background: '#e8fff4',
              borderRadius: 10,
              border: '1.5px solid #00B96B',
              cursor: 'pointer',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 22 }}>{currentNoise.icon}</span>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#00B96B' }}>{currentNoise.label}</div>
                <div style={{ fontSize: 12, color: '#52C41A', marginTop: 1 }}>{currentNoise.description} · {currentNoise.dailyCount}</div>
              </div>
            </div>
            <span style={{ color: '#00B96B', fontSize: 18 }}>›</span>
          </div>

          {/* 4档快速选择 */}
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
            {NOISE_LEVEL_CONFIGS.map((cfg) => (
              <button
                key={cfg.key}
                onClick={() => setNoiseLevel(cfg.key)}
                className={`noise-btn ${pref.noiseLevel === cfg.key ? 'active' : 'inactive'}`}
              >
                <div style={{ fontSize: 14 }}>{cfg.icon}</div>
                <div style={{ fontSize: 10, marginTop: 2 }}>{cfg.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* 订阅领域 */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 4 }}>📡 订阅领域</div>
          <div style={{ fontSize: 12, color: '#999', marginBottom: 12 }}>已选 {pref.domains.length} 个领域</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {DOMAIN_CONFIGS.map((d) => {
              const selected = pref.domains.includes(d.key)
              return (
                <div
                  key={d.key}
                  onClick={() => toggleDomain(d.key)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '12px 14px',
                    borderRadius: 10,
                    border: `1.5px solid ${selected ? d.color : '#f0f0f0'}`,
                    background: selected ? d.bgColor : '#fafafa',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                  }}
                >
                  <span style={{ fontSize: 22, marginRight: 12 }}>{d.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: selected ? d.color : '#1a1a1a' }}>{d.label}</div>
                    <div style={{ fontSize: 12, color: '#999', marginTop: 1 }}>{d.description}</div>
                  </div>
                  <div style={{
                    width: 22, height: 22, borderRadius: '50%',
                    background: selected ? d.color : '#f0f0f0',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: 'white', fontSize: 13, fontWeight: 700,
                  }}>
                    {selected ? '✓' : ''}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* 地区偏好 */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 4 }}>🌍 地区偏好</div>
          <div style={{ fontSize: 12, color: '#999', marginBottom: 12 }}>设置默认地区筛选</div>
          <div style={{ display: 'flex', gap: 8 }}>
            {REGION_OPTIONS.map((r) => {
              const selected = (pref.regionPref || 'all') === r.key
              return (
                <div
                  key={r.key}
                  onClick={() => setRegionPref(r.key)}
                  style={{
                    flex: 1,
                    padding: '12px 8px',
                    borderRadius: 10,
                    border: `1.5px solid ${selected ? '#00B96B' : '#f0f0f0'}`,
                    background: selected ? '#e8fff4' : '#fafafa',
                    cursor: 'pointer',
                    textAlign: 'center',
                    transition: 'all 0.2s',
                  }}
                >
                  <div style={{ fontSize: 22 }}>{r.icon}</div>
                  <div style={{ fontSize: 13, fontWeight: selected ? 600 : 400, color: selected ? '#00B96B' : '#333', marginTop: 4 }}>{r.label}</div>
                  <div style={{ fontSize: 10, color: '#999', marginTop: 2 }}>{r.desc}</div>
                </div>
              )
            })}
          </div>
        </div>

        {/* 情绪过滤 */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 12 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 4 }}>😊 情绪过滤</div>
          <div style={{ fontSize: 12, color: '#999', marginBottom: 12 }}>屏蔽特定情绪倾向的资讯（被屏蔽的情绪类型不会出现在信息流中）</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {SENTIMENT_OPTIONS.map((s) => {
              const blocked = (pref.blockedSentiments || []).includes(s.key)
              return (
                <div
                  key={s.key}
                  onClick={() => toggleBlockedSentiment(s.key)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: '12px 14px',
                    borderRadius: 10,
                    border: `1.5px solid ${blocked ? '#FF4D4F' : '#f0f0f0'}`,
                    background: blocked ? '#FFF2F0' : '#fafafa',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                  }}
                >
                  <span style={{ fontSize: 22, marginRight: 12 }}>{s.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: blocked ? '#FF4D4F' : '#1a1a1a' }}>{s.label}</div>
                    <div style={{ fontSize: 12, color: '#999', marginTop: 1 }}>{s.desc}</div>
                  </div>
                  <div style={{
                    width: 22, height: 22, borderRadius: '50%',
                    background: blocked ? '#FF4D4F' : '#f0f0f0',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: 'white', fontSize: 12, fontWeight: 700,
                  }}>
                    {blocked ? '✕' : ''}
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* 专属雷达词 */}
        <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>📡 专属雷达词</div>
            <span style={{ fontSize: 12, color: '#999' }}>{pref.radarWords.length}/20</span>
          </div>
          <div style={{ fontSize: 12, color: '#999', marginBottom: 12 }}>命中即强制置顶，穿透所有降噪档位</div>

          {/* 已添加的雷达词 */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            {pref.radarWords.map((word) => (
              <div
                key={word}
                style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '4px 10px', background: '#e8fff4', borderRadius: 20, border: '1px solid #b7ebd5' }}
              >
                <span style={{ fontSize: 13, color: '#00B96B', fontWeight: 500 }}>{word}</span>
                <button
                  onClick={() => removeRadarWord(word)}
                  style={{ background: 'none', border: 'none', color: '#52C41A', fontSize: 14, padding: 0, lineHeight: 1, cursor: 'pointer' }}
                >
                  ×
                </button>
              </div>
            ))}
          </div>

          {/* 输入框 */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
            <input
              value={radarInput}
              onChange={(e) => setRadarInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddRadar()}
              placeholder="输入关键词，按 Enter 添加"
              style={{ flex: 1, border: '1px solid #e0e0e0', borderRadius: 8, padding: '8px 12px', fontSize: 13, outline: 'none' }}
            />
            <button
              onClick={handleAddRadar}
              style={{ background: '#00B96B', color: 'white', border: 'none', borderRadius: 8, padding: '8px 16px', fontSize: 13, cursor: 'pointer' }}
            >
              添加
            </button>
          </div>

          {/* 推荐词 */}
          <div style={{ fontSize: 12, color: '#999', marginBottom: 8 }}>推荐雷达词：</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {SUGGESTED_RADAR_WORDS.filter((w) => !pref.radarWords.includes(w)).slice(0, 8).map((word) => (
              <button
                key={word}
                onClick={() => addRadarWord(word)}
                style={{ padding: '4px 10px', borderRadius: 20, border: '1px dashed #b7ebd5', background: 'white', color: '#00B96B', fontSize: 12, cursor: 'pointer' }}
              >
                + {word}
              </button>
            ))}
          </div>
        </div>
      </div>

      <NoiseLevelSheet
        open={noiseOpen}
        current={pref.noiseLevel}
        onSelect={setNoiseLevel}
        onClose={() => setNoiseOpen(false)}
      />
    </div>
  )
}
