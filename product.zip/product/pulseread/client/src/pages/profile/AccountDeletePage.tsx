import { useState } from 'react'
import { useLocation } from 'wouter'
import { useUser } from '../../stores/useAppStore'

export default function AccountDeletePage() {
  const [, navigate] = useLocation()
  const { user, logout } = useUser()
  const [step, setStep] = useState<'info' | 'confirm' | 'done'>('info')
  const [reason, setReason] = useState('')

  const reasons = [
    '不再需要此服务',
    '隐私安全顾虑',
    '使用频率太低',
    '功能不满足需求',
    '其他原因',
  ]

  const handleDelete = () => {
    setStep('done')
    // 模拟 30 天冷静期
    setTimeout(() => {
      logout()
      navigate('/feed')
    }, 2000)
  }

  return (
    <div style={{ background: '#f5f5f5', minHeight: '100vh' }}>
      {/* 顶部导航 */}
      <div style={{ background: 'white', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, zIndex: 50 }}>
        <button onClick={() => navigate('/profile')} style={{ background: 'none', border: 'none', fontSize: 20, padding: 0, color: '#333' }}>←</button>
        <span style={{ fontSize: 15, fontWeight: 600, color: '#1a1a1a' }}>账号注销</span>
      </div>

      <div style={{ padding: 12 }}>
        {step === 'info' && (
          <>
            {/* 警告提示 */}
            <div style={{ background: '#FFF2F0', borderRadius: 12, padding: 16, marginBottom: 12, border: '1px solid #FFCCC7' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span style={{ fontSize: 20 }}>⚠️</span>
                <span style={{ fontSize: 15, fontWeight: 700, color: '#FF4D4F' }}>注销账号须知</span>
              </div>
              <div style={{ fontSize: 13, color: '#666', lineHeight: 1.8 }}>
                注销账号后，您的以下数据将在 <strong style={{ color: '#FF4D4F' }}>30 天冷静期</strong> 后被永久删除：
              </div>
            </div>

            {/* 将被删除的数据 */}
            <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 12 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>将被删除的数据</div>
              {[
                { icon: '📖', label: '阅读历史', value: `${user.readCount} 条记录` },
                { icon: '⭐', label: '收藏内容', value: `${user.collectCount} 篇文章` },
                { icon: '📡', label: '雷达词配置', value: `${user.radarWordCount} 个关键词` },
                { icon: '🎛️', label: '偏好设置', value: '降噪档位、领域订阅等' },
                { icon: '💎', label: '会员权益', value: user.plan === 'free' ? '免费版' : 'Pro 会员剩余时长' },
              ].map((item) => (
                <div key={item.label} style={{ display: 'flex', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
                  <span style={{ fontSize: 18, marginRight: 12 }}>{item.icon}</span>
                  <span style={{ flex: 1, fontSize: 13, color: '#333' }}>{item.label}</span>
                  <span style={{ fontSize: 12, color: '#999' }}>{item.value}</span>
                </div>
              ))}
            </div>

            {/* 冷静期说明 */}
            <div style={{ background: '#E6F4FF', borderRadius: 12, padding: 16, marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <span style={{ fontSize: 16 }}>ℹ️</span>
                <span style={{ fontSize: 14, fontWeight: 600, color: '#1677FF' }}>30 天冷静期</span>
              </div>
              <div style={{ fontSize: 12, color: '#666', lineHeight: 1.7 }}>
                提交注销申请后，账号将进入 30 天冷静期。在此期间内重新登录即可取消注销。冷静期结束后，所有数据将被不可逆地删除。
              </div>
            </div>

            <button
              onClick={() => setStep('confirm')}
              style={{ width: '100%', padding: 14, background: 'white', border: '1.5px solid #FF4D4F', borderRadius: 12, fontSize: 14, color: '#FF4D4F', fontWeight: 600, cursor: 'pointer' }}
            >
              我已了解，继续注销
            </button>
          </>
        )}

        {step === 'confirm' && (
          <>
            <div style={{ background: 'white', borderRadius: 12, padding: 16, marginBottom: 12 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>请选择注销原因</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {reasons.map((r) => (
                  <div
                    key={r}
                    onClick={() => setReason(r)}
                    style={{
                      padding: '12px 14px',
                      borderRadius: 10,
                      border: `1.5px solid ${reason === r ? '#FF4D4F' : '#f0f0f0'}`,
                      background: reason === r ? '#FFF2F0' : '#fafafa',
                      cursor: 'pointer',
                      fontSize: 13,
                      color: reason === r ? '#FF4D4F' : '#333',
                      fontWeight: reason === r ? 600 : 400,
                      transition: 'all 0.2s',
                    }}
                  >
                    {r}
                  </div>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10 }}>
              <button
                onClick={() => setStep('info')}
                style={{ flex: 1, padding: 14, background: 'white', border: '1px solid #e0e0e0', borderRadius: 12, fontSize: 14, color: '#666', cursor: 'pointer' }}
              >
                返回
              </button>
              <button
                onClick={handleDelete}
                disabled={!reason}
                style={{
                  flex: 1, padding: 14,
                  background: reason ? '#FF4D4F' : '#ffccc7',
                  border: 'none', borderRadius: 12, fontSize: 14, color: 'white', fontWeight: 600,
                  cursor: reason ? 'pointer' : 'not-allowed',
                  opacity: reason ? 1 : 0.6,
                }}
              >
                确认注销
              </button>
            </div>
          </>
        )}

        {step === 'done' && (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#1a1a1a', marginBottom: 8 }}>注销申请已提交</div>
            <div style={{ fontSize: 14, color: '#666', lineHeight: 1.7 }}>
              您的账号已进入 30 天冷静期。<br />
              在此期间重新登录即可取消注销。
            </div>
            <div style={{ fontSize: 12, color: '#999', marginTop: 20 }}>即将返回首页...</div>
          </div>
        )}
      </div>
    </div>
  )
}
