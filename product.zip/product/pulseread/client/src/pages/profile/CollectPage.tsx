import { useLocation } from 'wouter'
import { useFeed } from '../../stores/useAppStore'
import { DOMAIN_CONFIGS } from '../../data/mockData'

export default function CollectPage() {
  const [, navigate] = useLocation()
  const { articles, toggleCollect } = useFeed('all', 'all')
  const collected = articles.filter((a) => a.isCollected)

  const getDomainConfig = (key: string) => DOMAIN_CONFIGS.find((d) => d.key === key)

  return (
    <div style={{ paddingBottom: 24, background: '#f5f5f5', minHeight: '100vh' }}>
      {/* 顶部导航 */}
      <div style={{ background: 'white', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, zIndex: 50 }}>
        <button onClick={() => navigate('/profile')} style={{ background: 'none', border: 'none', fontSize: 22, color: '#333', padding: 0, lineHeight: 1 }}>‹</button>
        <span style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a' }}>我的收藏</span>
        <span style={{ marginLeft: 'auto', fontSize: 13, color: '#999' }}>{collected.length} 篇</span>
      </div>

      {collected.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '80px 20px', color: '#bbb' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>⭐</div>
          <div style={{ fontSize: 15, fontWeight: 500, color: '#999' }}>暂无收藏</div>
          <div style={{ fontSize: 13, marginTop: 6 }}>在资讯卡片上点击 ☆ 即可收藏</div>
        </div>
      ) : (
        <div style={{ padding: '12px' }}>
          {collected.map((article) => {
            const dc = getDomainConfig(article.domain)
            return (
              <div
                key={article.id}
                className="article-card"
                onClick={() => navigate(`/article/${article.id}`)}
                style={{ cursor: 'pointer' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                  <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 4, background: dc?.bgColor, color: dc?.textColor, fontWeight: 500 }}>
                    {dc?.icon} {dc?.label}
                  </span>
                  <span style={{ fontSize: 11, color: '#999' }}>{article.source}</span>
                  <span style={{ fontSize: 11, color: '#bbb', marginLeft: 'auto' }}>{article.publishTime}</span>
                </div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#1a1a1a', lineHeight: 1.5, marginBottom: 6 }}>{article.title}</div>
                <div style={{ fontSize: 12, color: '#888', lineHeight: 1.6, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{article.summary}</div>
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 10 }}>
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleCollect(article.id) }}
                    style={{ background: '#FFF7E6', border: 'none', borderRadius: 16, padding: '4px 12px', fontSize: 12, color: '#FA8C16', cursor: 'pointer', fontWeight: 500 }}
                  >
                    ⭐ 取消收藏
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
