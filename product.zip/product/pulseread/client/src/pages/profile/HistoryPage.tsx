import { useLocation } from 'wouter'
import { useReadHistory } from '../../stores/useAppStore'
import { DOMAIN_CONFIGS } from '../../data/mockData'

export default function HistoryPage() {
  const [, navigate] = useLocation()
  const { history, clearHistory } = useReadHistory()

  const getDomainConfig = (key: string) => DOMAIN_CONFIGS.find((d) => d.key === key)

  return (
    <div style={{ paddingBottom: 24, background: '#f5f5f5', minHeight: '100vh' }}>
      {/* 顶部导航 */}
      <div style={{ background: 'white', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, zIndex: 50 }}>
        <button onClick={() => navigate('/profile')} style={{ background: 'none', border: 'none', fontSize: 22, color: '#333', padding: 0, lineHeight: 1 }}>‹</button>
        <span style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a' }}>阅读历史</span>
        {history.length > 0 && (
          <button
            onClick={clearHistory}
            style={{ marginLeft: 'auto', background: 'none', border: 'none', fontSize: 13, color: '#FF4D4F', cursor: 'pointer' }}
          >
            清除
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '80px 20px', color: '#bbb' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📖</div>
          <div style={{ fontSize: 15, fontWeight: 500, color: '#999' }}>暂无阅读记录</div>
          <div style={{ fontSize: 13, marginTop: 6 }}>点击资讯卡片即可开始阅读</div>
        </div>
      ) : (
        <div style={{ padding: '12px' }}>
          {history.map((article) => {
            const dc = getDomainConfig(article.domain)
            return (
              <div
                key={article.id}
                className="article-card"
                onClick={() => navigate(`/article/${article.id}`)}
                style={{ cursor: 'pointer', opacity: 0.9 }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                  <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 4, background: dc?.bgColor, color: dc?.textColor, fontWeight: 500 }}>
                    {dc?.icon} {dc?.label}
                  </span>
                  <span style={{ fontSize: 11, color: '#999' }}>{article.source}</span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, marginLeft: 'auto', fontSize: 11, color: '#00B96B', background: '#e8fff4', padding: '1px 6px', borderRadius: 8 }}>
                    ✓ 已读
                  </span>
                </div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#888', lineHeight: 1.5, marginBottom: 6 }}>{article.title}</div>
                <div style={{ fontSize: 12, color: '#aaa', lineHeight: 1.6, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{article.summary}</div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
