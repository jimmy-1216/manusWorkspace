import { useLocation } from 'wouter'
import { useUser } from '../../stores/useAppStore'

export default function ProfilePage() {
  const [, navigate] = useLocation()
  const { user, isLoggedIn, logout } = useUser()

  const planInfo = {
    free: { label: '免费版', color: '#8C8C8C', bgColor: '#f5f5f5', limit: '50 条/日' },
    pro: { label: 'Pro', color: '#FA8C16', bgColor: '#FFF7E6', limit: '无限' },
    enterprise: { label: '企业版', color: '#722ED1', bgColor: '#F9F0FF', limit: '无限 + API' },
  }

  const current = planInfo[user.plan]

  const menuItems = [
    { icon: '⭐', label: '我的收藏', count: user.collectCount, path: '/profile/collect' },
    { icon: '📖', label: '阅读历史', count: user.readCount, path: '/profile/history' },
    { icon: '📡', label: '雷达词管理', count: user.radarWordCount, path: '/profile/radar' },
    { icon: '📊', label: '数据统计', count: null, path: '/profile/stats' },
  ]

  const otherItems = [
    { icon: '💬', label: '意见反馈', path: null },
    { icon: '📖', label: '使用帮助', path: null },
    { icon: 'ℹ️', label: '关于微澜', path: null },
  ]

  return (
    <div style={{ paddingBottom: 70, background: '#f5f5f5', minHeight: '100vh' }}>
      {/* 顶部个人卡片 */}
      <div style={{ background: 'linear-gradient(135deg, #00B96B 0%, #52C41A 100%)', padding: '24px 16px 32px', color: 'white' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 60, height: 60, borderRadius: '50%', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, fontWeight: 700, color: '#00B96B' }}>
            {user.nickname.charAt(0)}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 4 }}>{user.nickname}</div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 10px', background: current.bgColor, borderRadius: 12, fontSize: 12, fontWeight: 600, color: current.color }}>
              {current.label} · {current.limit}
            </div>
          </div>
          <button style={{ background: 'rgba(255,255,255,0.2)', border: 'none', borderRadius: 20, padding: '6px 14px', color: 'white', fontSize: 12, cursor: 'pointer' }}>
            设置
          </button>
        </div>

        {/* 统计卡片 */}
        <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
          {[
            { label: '累计阅读', value: user.readCount, path: '/profile/history' },
            { label: '我的收藏', value: user.collectCount, path: '/profile/collect' },
            { label: '雷达词', value: user.radarWordCount, path: '/profile/radar' },
          ].map((stat) => (
            <div
              key={stat.label}
              onClick={() => stat.path && navigate(stat.path)}
              style={{ flex: 1, background: 'rgba(255,255,255,0.15)', borderRadius: 12, padding: '12px', textAlign: 'center', backdropFilter: 'blur(10px)', cursor: stat.path ? 'pointer' : 'default' }}
            >
              <div style={{ fontSize: 22, fontWeight: 700 }}>{stat.value}</div>
              <div style={{ fontSize: 12, opacity: 0.9, marginTop: 2 }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 功能列表 */}
      <div style={{ padding: '12px' }}>
        {/* 会员升级 */}
        {user.plan === 'free' && (
          <div style={{ background: 'linear-gradient(135deg, #FA8C16 0%, #FFA940 100%)', borderRadius: 12, padding: '16px', marginBottom: 12, color: 'white', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: -20, right: -20, fontSize: 80, opacity: 0.15 }}>💎</div>
            <div style={{ fontSize: 16, fontWeight: 700, marginBottom: 6, position: 'relative' }}>升级 Pro，解锁全部功能</div>
            <div style={{ fontSize: 13, opacity: 0.95, marginBottom: 12, position: 'relative' }}>无限资讯 · 无限雷达词 · 无广告 · 数据导出</div>
            <button style={{ background: 'white', color: '#FA8C16', border: 'none', borderRadius: 20, padding: '8px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer', position: 'relative' }}>
              立即升级 ¥99/月
            </button>
          </div>
        )}

        {/* 功能入口 */}
        <div style={{ background: 'white', borderRadius: 12, overflow: 'hidden', marginBottom: 12 }}>
          {menuItems.map((item, i) => (
            <div
              key={item.label}
              onClick={() => item.path ? navigate(item.path) : undefined}
              style={{
                display: 'flex', alignItems: 'center', padding: '14px 16px',
                borderBottom: i < menuItems.length - 1 ? '1px solid #f5f5f5' : 'none',
                cursor: item.path ? 'pointer' : 'default',
                transition: 'background 0.15s',
              }}
              onMouseEnter={(e) => { if (item.path) e.currentTarget.style.background = '#fafafa' }}
              onMouseLeave={(e) => { e.currentTarget.style.background = 'white' }}
            >
              <span style={{ fontSize: 20, marginRight: 12 }}>{item.icon}</span>
              <span style={{ flex: 1, fontSize: 14, color: '#333' }}>{item.label}</span>
              {item.count !== null && (
                <span style={{ fontSize: 12, color: '#999', marginRight: 6 }}>{item.count}</span>
              )}
              <span style={{ color: item.path ? '#ccc' : '#e8e8e8', fontSize: 16 }}>›</span>
            </div>
          ))}
        </div>

        {/* 其他功能 */}
        <div style={{ background: 'white', borderRadius: 12, overflow: 'hidden', marginBottom: 12 }}>
          {otherItems.map((item, i) => (
            <div
              key={item.label}
              style={{
                display: 'flex', alignItems: 'center', padding: '14px 16px',
                borderBottom: i < otherItems.length - 1 ? '1px solid #f5f5f5' : 'none',
                cursor: 'pointer',
              }}
            >
              <span style={{ fontSize: 20, marginRight: 12 }}>{item.icon}</span>
              <span style={{ flex: 1, fontSize: 14, color: '#333' }}>{item.label}</span>
              <span style={{ color: '#ccc', fontSize: 16 }}>›</span>
            </div>
          ))}
        </div>

        {/* 账号管理 */}
        {isLoggedIn && (
          <div style={{ background: 'white', borderRadius: 12, overflow: 'hidden', marginBottom: 12 }}>
            <div
              onClick={logout}
              style={{
                display: 'flex', alignItems: 'center', padding: '14px 16px',
                borderBottom: '1px solid #f5f5f5',
                cursor: 'pointer',
              }}
            >
              <span style={{ fontSize: 20, marginRight: 12 }}>🚪</span>
              <span style={{ flex: 1, fontSize: 14, color: '#333' }}>退出登录</span>
              <span style={{ color: '#ccc', fontSize: 16 }}>›</span>
            </div>
            <div
              onClick={() => navigate('/profile/delete-account')}
              style={{
                display: 'flex', alignItems: 'center', padding: '14px 16px',
                cursor: 'pointer',
              }}
            >
              <span style={{ fontSize: 20, marginRight: 12 }}>⚠️</span>
              <span style={{ flex: 1, fontSize: 14, color: '#FF4D4F' }}>注销账号</span>
              <span style={{ fontSize: 11, color: '#999', marginRight: 6 }}>30天冷静期</span>
              <span style={{ color: '#ccc', fontSize: 16 }}>›</span>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
