import { useState } from 'react'
import { useLocation } from 'wouter'
import { usePreference } from '../../stores/useAppStore'
import { SUGGESTED_RADAR_WORDS } from '../../data/mockData'

export default function RadarPage() {
  const [, navigate] = useLocation()
  const { pref, addRadarWord, removeRadarWord } = usePreference()
  const [input, setInput] = useState('')
  const [suggestions, setSuggestions] = useState<string[]>([])

  // 实时联想：从 SUGGESTED_RADAR_WORDS 中过滤，排除已添加的
  const handleInput = (val: string) => {
    setInput(val)
    if (val.trim().length === 0) {
      setSuggestions([])
      return
    }
    const filtered = SUGGESTED_RADAR_WORDS.filter(
      (w) => w.includes(val) && !pref.radarWords.includes(w)
    )
    setSuggestions(filtered.slice(0, 5))
  }

  const handleAdd = (word: string) => {
    const w = word.trim()
    if (!w) return
    if (pref.radarWords.length >= 20) {
      alert('最多添加 20 个雷达词')
      return
    }
    addRadarWord(w)
    setInput('')
    setSuggestions([])
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleAdd(input)
  }

  return (
    <div style={{ paddingBottom: 40, background: '#f5f5f5', minHeight: '100vh' }}>
      {/* 顶部导航 */}
      <div style={{ background: 'white', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, zIndex: 50 }}>
        <button onClick={() => navigate('/profile')} style={{ background: 'none', border: 'none', fontSize: 22, color: '#333', padding: 0, lineHeight: 1 }}>‹</button>
        <span style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a' }}>雷达词管理</span>
        <span style={{ marginLeft: 'auto', fontSize: 13, color: '#999' }}>{pref.radarWords.length}/20</span>
      </div>

      <div style={{ padding: '16px 12px' }}>
        {/* 说明 */}
        <div style={{ background: '#e8fff4', borderRadius: 10, padding: '10px 14px', marginBottom: 16, fontSize: 12, color: '#00B96B', lineHeight: 1.7 }}>
          📡 <strong>专属雷达词</strong>：命中关键词的资讯将强制置顶，穿透所有降噪档位，确保不错过重要信息。
        </div>

        {/* 输入框 */}
        <div style={{ background: 'white', borderRadius: 12, padding: '12px 14px', marginBottom: 4, position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 16 }}>📡</span>
            <input
              value={input}
              onChange={(e) => handleInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="输入关键词，回车添加..."
              style={{
                flex: 1, border: 'none', outline: 'none', fontSize: 14, color: '#333',
                background: 'transparent',
              }}
            />
            <button
              onClick={() => handleAdd(input)}
              disabled={!input.trim()}
              style={{
                background: input.trim() ? '#00B96B' : '#f0f0f0',
                color: input.trim() ? 'white' : '#bbb',
                border: 'none', borderRadius: 16, padding: '5px 14px',
                fontSize: 13, fontWeight: 600, cursor: input.trim() ? 'pointer' : 'default',
                transition: 'all 0.2s',
              }}
            >
              添加
            </button>
          </div>

          {/* 实时联想下拉 */}
          {suggestions.length > 0 && (
            <div style={{
              position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 100,
              background: 'white', borderRadius: '0 0 12px 12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.1)', overflow: 'hidden',
            }}>
              {suggestions.map((s) => (
                <div
                  key={s}
                  onClick={() => handleAdd(s)}
                  style={{
                    padding: '10px 16px', fontSize: 13, color: '#333', cursor: 'pointer',
                    borderBottom: '1px solid #f5f5f5', display: 'flex', alignItems: 'center', gap: 8,
                  }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = '#f9f9f9')}
                  onMouseLeave={(e) => (e.currentTarget.style.background = 'white')}
                >
                  <span style={{ fontSize: 12, color: '#00B96B' }}>📡</span>
                  <span>{s}</span>
                  <span style={{ marginLeft: 'auto', fontSize: 11, color: '#bbb' }}>点击添加</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 推荐词 */}
        <div style={{ marginBottom: 16, marginTop: 8 }}>
          <div style={{ fontSize: 12, color: '#999', marginBottom: 8, paddingLeft: 2 }}>推荐词</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {SUGGESTED_RADAR_WORDS.filter((w) => !pref.radarWords.includes(w)).map((w) => (
              <button
                key={w}
                onClick={() => handleAdd(w)}
                style={{
                  padding: '5px 12px', borderRadius: 16, border: '1px dashed #d9d9d9',
                  background: 'white', fontSize: 12, color: '#666', cursor: 'pointer',
                  transition: 'all 0.15s',
                }}
                onMouseEnter={(e) => { e.currentTarget.style.borderColor = '#00B96B'; e.currentTarget.style.color = '#00B96B' }}
                onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#d9d9d9'; e.currentTarget.style.color = '#666' }}
              >
                + {w}
              </button>
            ))}
          </div>
        </div>

        {/* 已添加的雷达词 */}
        <div style={{ background: 'white', borderRadius: 12, overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid #f5f5f5', fontSize: 13, fontWeight: 600, color: '#333' }}>
            已添加的雷达词
          </div>
          {pref.radarWords.length === 0 ? (
            <div style={{ padding: '32px 16px', textAlign: 'center', color: '#bbb', fontSize: 13 }}>
              暂未添加雷达词
            </div>
          ) : (
            pref.radarWords.map((word, i) => (
              <div
                key={word}
                style={{
                  display: 'flex', alignItems: 'center', padding: '13px 16px',
                  borderBottom: i < pref.radarWords.length - 1 ? '1px solid #f5f5f5' : 'none',
                }}
              >
                <span style={{ fontSize: 14, color: '#00B96B', marginRight: 8 }}>📡</span>
                <span style={{ flex: 1, fontSize: 14, color: '#333', fontWeight: 500 }}>{word}</span>
                <button
                  onClick={() => removeRadarWord(word)}
                  style={{ background: 'none', border: 'none', fontSize: 18, color: '#ccc', cursor: 'pointer', lineHeight: 1, padding: '0 4px' }}
                >
                  ×
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
