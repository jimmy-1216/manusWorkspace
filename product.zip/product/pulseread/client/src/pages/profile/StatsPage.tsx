import { useLocation } from 'wouter'
import { useUser, useReadHistory } from '../../stores/useAppStore'
import { DOMAIN_CONFIGS } from '../../data/mockData'

export default function StatsPage() {
  const [, navigate] = useLocation()
  const { user } = useUser()
  const { history } = useReadHistory()

  // 按领域统计已读数量
  const domainStats = DOMAIN_CONFIGS.map((dc) => {
    const count = history.filter((a) => a.domain === dc.key).length
    return { ...dc, count }
  }).sort((a, b) => b.count - a.count)

  const totalRead = history.length
  const collected = user.collectCount
  const radarCount = user.radarWordCount

  // 本周阅读（取最近7篇模拟）
  const weekRead = Math.min(totalRead, 7)

  // 阅读偏好最强领域
  const topDomain = domainStats[0]

  return (
    <div style={{ paddingBottom: 40, background: '#f5f5f5', minHeight: '100vh' }}>
      {/* 顶部导航 */}
      <div style={{ background: 'white', padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, zIndex: 50 }}>
        <button onClick={() => navigate('/profile')} style={{ background: 'none', border: 'none', fontSize: 22, color: '#333', padding: 0, lineHeight: 1 }}>‹</button>
        <span style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a' }}>数据统计</span>
      </div>

      <div style={{ padding: '16px 12px' }}>
        {/* 总览卡片 */}
        <div style={{ background: 'linear-gradient(135deg, #00B96B 0%, #52C41A 100%)', borderRadius: 16, padding: '20px', marginBottom: 16, color: 'white' }}>
          <div style={{ fontSize: 13, opacity: 0.85, marginBottom: 16 }}>我的阅读总览</div>
          <div style={{ display: 'flex', gap: 0 }}>
            {[
              { label: '累计阅读', value: user.readCount, unit: '篇' },
              { label: '本周阅读', value: weekRead, unit: '篇' },
              { label: '我的收藏', value: collected, unit: '篇' },
              { label: '雷达词', value: radarCount, unit: '个' },
            ].map((item, i) => (
              <div key={item.label} style={{ flex: 1, textAlign: 'center', borderLeft: i > 0 ? '1px solid rgba(255,255,255,0.2)' : 'none', padding: '0 4px' }}>
                <div style={{ fontSize: 24, fontWeight: 800, lineHeight: 1 }}>{item.value}</div>
                <div style={{ fontSize: 10, opacity: 0.8, marginTop: 4 }}>{item.unit}</div>
                <div style={{ fontSize: 11, opacity: 0.75, marginTop: 2 }}>{item.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* 领域阅读分布 */}
        <div style={{ background: 'white', borderRadius: 12, padding: '16px', marginBottom: 16 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 14 }}>领域阅读分布</div>
          {totalRead === 0 ? (
            <div style={{ textAlign: 'center', padding: '24px 0', color: '#bbb', fontSize: 13 }}>暂无阅读记录</div>
          ) : (
            domainStats.map((dc) => {
              const pct = totalRead > 0 ? Math.round((dc.count / totalRead) * 100) : 0
              return (
                <div key={dc.key} style={{ marginBottom: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                    <span style={{ fontSize: 13, color: '#333' }}>{dc.icon} {dc.label}</span>
                    <span style={{ fontSize: 12, color: '#999' }}>{dc.count} 篇 · {pct}%</span>
                  </div>
                  <div style={{ height: 6, background: '#f5f5f5', borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${pct}%`, background: dc.color, borderRadius: 3, transition: 'width 0.5s ease' }} />
                  </div>
                </div>
              )
            })
          )}
        </div>

        {/* 阅读偏好洞察 */}
        <div style={{ background: 'white', borderRadius: 12, padding: '16px', marginBottom: 16 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>阅读偏好洞察</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              {
                icon: '🏆',
                label: '最常阅读领域',
                value: totalRead > 0 && topDomain.count > 0 ? `${topDomain.icon} ${topDomain.label}` : '暂无数据',
                color: totalRead > 0 && topDomain.count > 0 ? topDomain.color : '#bbb',
              },
              {
                icon: '📡',
                label: '雷达词数量',
                value: `${radarCount} 个`,
                color: '#00B96B',
              },
              {
                icon: '⭐',
                label: '收藏率',
                value: user.readCount > 0 ? `${Math.round((collected / user.readCount) * 100)}%` : '0%',
                color: '#FA8C16',
              },
            ].map((item) => (
              <div key={item.label} style={{ display: 'flex', alignItems: 'center', padding: '10px 12px', background: '#fafafa', borderRadius: 10 }}>
                <span style={{ fontSize: 20, marginRight: 12 }}>{item.icon}</span>
                <span style={{ flex: 1, fontSize: 13, color: '#666' }}>{item.label}</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: item.color }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 最近阅读 */}
        {history.length > 0 && (
          <div style={{ background: 'white', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ padding: '14px 16px', borderBottom: '1px solid #f5f5f5', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>最近阅读</span>
              <button onClick={() => navigate('/profile/history')} style={{ background: 'none', border: 'none', fontSize: 12, color: '#00B96B', cursor: 'pointer' }}>查看全部 ›</button>
            </div>
            {history.slice(0, 5).map((article, i) => {
              const dc = DOMAIN_CONFIGS.find((d) => d.key === article.domain)
              return (
                <div
                  key={article.id}
                  onClick={() => navigate(`/article/${article.id}`)}
                  style={{ padding: '12px 16px', borderBottom: i < Math.min(history.length, 5) - 1 ? '1px solid #f5f5f5' : 'none', cursor: 'pointer' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                    <span style={{ fontSize: 10, padding: '1px 6px', borderRadius: 4, background: dc?.bgColor, color: dc?.textColor }}>{dc?.icon} {dc?.label}</span>
                    <span style={{ fontSize: 10, color: '#bbb', marginLeft: 'auto' }}>{article.publishTime}</span>
                  </div>
                  <div style={{ fontSize: 13, color: '#888', lineHeight: 1.5, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                    {article.title}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
