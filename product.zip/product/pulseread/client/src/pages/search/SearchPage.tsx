import { useState } from 'react'
import { Link } from 'wouter'
import { MOCK_ARTICLES, HOT_SEARCH_WORDS } from '../../data/mockData'
import type { Article } from '../../types'

export default function SearchPage() {
  const [keyword, setKeyword] = useState('')
  const [results, setResults] = useState<Article[]>([])
  const [searched, setSearched] = useState(false)
  const [history, setHistory] = useState<string[]>(['GPT-5', 'A股', '招投标'])

  const handleSearch = (kw: string) => {
    if (!kw.trim()) return
    const q = kw.trim()
    setKeyword(q)
    const found = MOCK_ARTICLES.filter(
      (a) => a.title.includes(q) || a.summary.includes(q) || a.tags?.includes(q) || a.radarWords?.includes(q)
    )
    setResults(found)
    setSearched(true)
    if (!history.includes(q)) setHistory((prev) => [q, ...prev].slice(0, 10))
  }

  const clearHistory = () => setHistory([])

  return (
    <div style={{ paddingBottom: 70 }}>
      {/* 搜索框 */}
      <div style={{ background: 'white', padding: '12px 16px', borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, zIndex: 50 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#f5f5f5', borderRadius: 24, padding: '8px 14px' }}>
          <span style={{ fontSize: 16, color: '#999' }}>🔍</span>
          <input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch(keyword)}
            placeholder="搜索资讯、关键词..."
            style={{ flex: 1, border: 'none', outline: 'none', background: 'transparent', fontSize: 14, color: '#333' }}
          />
          {keyword && (
            <button onClick={() => { setKeyword(''); setSearched(false); setResults([]) }} style={{ background: 'none', border: 'none', color: '#999', fontSize: 16, padding: 0 }}>✕</button>
          )}
          <button
            onClick={() => handleSearch(keyword)}
            style={{ background: '#00B96B', color: 'white', border: 'none', borderRadius: 16, padding: '4px 14px', fontSize: 13, cursor: 'pointer' }}
          >
            搜索
          </button>
        </div>
      </div>

      <div style={{ padding: '16px 16px 0' }}>
        {!searched ? (
          <>
            {/* 搜索历史 */}
            {history.length > 0 && (
              <div style={{ marginBottom: 24 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                  <span style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a' }}>搜索历史</span>
                  <button onClick={clearHistory} style={{ background: 'none', border: 'none', fontSize: 12, color: '#999', cursor: 'pointer' }}>清除</button>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {history.map((h) => (
                    <button
                      key={h}
                      onClick={() => handleSearch(h)}
                      style={{ padding: '5px 14px', borderRadius: 20, border: '1px solid #e0e0e0', background: 'white', fontSize: 13, color: '#333', cursor: 'pointer' }}
                    >
                      {h}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 热门搜索 */}
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>🔥 热门搜索</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
                {HOT_SEARCH_WORDS.map((word, i) => (
                  <button
                    key={word}
                    onClick={() => handleSearch(word)}
                    style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: '1px solid #f5f5f5', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left', width: '100%' }}
                  >
                    <span style={{
                      minWidth: 20, height: 20, borderRadius: 4,
                      background: i < 3 ? '#FF4D4F' : '#f0f0f0',
                      color: i < 3 ? 'white' : '#999',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 11, fontWeight: 700,
                    }}>{i + 1}</span>
                    <span style={{ fontSize: 14, color: '#333' }}>{word}</span>
                    <span style={{ marginLeft: 'auto', fontSize: 12, color: '#ccc' }}>›</span>
                  </button>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div>
            <div style={{ fontSize: 13, color: '#999', marginBottom: 12 }}>
              找到 <span style={{ color: '#00B96B', fontWeight: 600 }}>{results.length}</span> 条相关资讯
            </div>
            {results.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '60px 0', color: '#999' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
                <div style={{ fontSize: 15 }}>未找到相关资讯</div>
                <div style={{ fontSize: 13, marginTop: 6 }}>换个关键词试试</div>
              </div>
            ) : (
              results.map((article) => (
                <Link key={article.id} href={`/article/${article.id}`}>
                  <div style={{ background: 'white', borderRadius: 12, padding: 14, marginBottom: 8, boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
                    <div style={{ fontSize: 14, fontWeight: 600, color: '#1a1a1a', lineHeight: 1.5, marginBottom: 6 }}>{article.title}</div>
                    <div style={{ fontSize: 12, color: '#999' }}>{article.source} · {article.publishTime}</div>
                  </div>
                </Link>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  )
}
