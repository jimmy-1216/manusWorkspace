import { useState, useEffect } from 'react'
import { MOCK_ARTICLES } from '../data/mockData'
import type { Article, NoiseLevel, DomainType, RegionType, UserPreference } from '../types'

const NOISE_THRESHOLDS: Record<NoiseLevel, number> = {
  open: 0,
  focus: 60,
  major: 75,
  quake: 88,
}

// 全局状态（模块级，所有 hook 实例共享）
let globalPreference: UserPreference = {
  noiseLevel: 'focus',
  domains: ['tech', 'finance', 'policy', 'commerce'],
  radarWords: ['GPT-5', 'A股', '招投标'],
  enableAutoTranslate: false,
  regionPref: 'all' as RegionType,
  blockedSentiments: [] as string[],
}

let globalUser = {
  id: 1,
  nickname: '微澜用户',
  plan: 'free' as const,
  readCount: 128,
  collectCount: 23,
  radarWordCount: 3,
}

let globalArticles = [...MOCK_ARTICLES]
// 已读文章 ID 集合
let globalReadIds: Set<number> = new Set()
// 阅读历史（有序，最新在前）
let globalReadHistory: Article[] = []

let listeners: Array<() => void> = []

// 全局用户状态（模块级，所有 hook 实例共享）
let globalHasOnboarded: boolean = !!localStorage.getItem('pulseread_onboarded')
let globalIsLoggedIn: boolean = !!localStorage.getItem('pulseread_logged_in')

function notify() {
  listeners.forEach((fn) => fn())
}

export function usePreference() {
  const [pref, setPref] = useState<UserPreference>(globalPreference)

  useEffect(() => {
    const handler = () => setPref({ ...globalPreference })
    listeners.push(handler)
    return () => { listeners = listeners.filter((l) => l !== handler) }
  }, [])

  const setNoiseLevel = (level: NoiseLevel) => {
    globalPreference = { ...globalPreference, noiseLevel: level }
    notify()
  }

  const toggleDomain = (domain: DomainType) => {
    const domains = globalPreference.domains.includes(domain)
      ? globalPreference.domains.filter((d) => d !== domain)
      : [...globalPreference.domains, domain]
    globalPreference = { ...globalPreference, domains }
    notify()
  }

  const addRadarWord = (word: string) => {
    if (!globalPreference.radarWords.includes(word)) {
      globalPreference = { ...globalPreference, radarWords: [...globalPreference.radarWords, word] }
      globalUser = { ...globalUser, radarWordCount: globalPreference.radarWords.length }
      notify()
    }
  }

  const removeRadarWord = (word: string) => {
    globalPreference = { ...globalPreference, radarWords: globalPreference.radarWords.filter((w) => w !== word) }
    globalUser = { ...globalUser, radarWordCount: globalPreference.radarWords.length }
    notify()
  }

  const setRegionPref = (region: RegionType) => {
    globalPreference = { ...globalPreference, regionPref: region }
    notify()
  }

  const toggleBlockedSentiment = (sentiment: string) => {
    const blocked = globalPreference.blockedSentiments || []
    const newBlocked = blocked.includes(sentiment)
      ? blocked.filter((s: string) => s !== sentiment)
      : [...blocked, sentiment]
    globalPreference = { ...globalPreference, blockedSentiments: newBlocked }
    notify()
  }

  return { pref, setNoiseLevel, toggleDomain, addRadarWord, removeRadarWord, setRegionPref, toggleBlockedSentiment }
}

export function useFeed(domain: DomainType | 'all', region: RegionType) {
  const [articles, setArticles] = useState<Article[]>([])
  const [pref, setPref] = useState<UserPreference>(globalPreference)
  const [readIds, setReadIds] = useState<Set<number>>(new Set(globalReadIds))

  useEffect(() => {
    const handler = () => {
      setPref({ ...globalPreference })
      setReadIds(new Set(globalReadIds))
    }
    listeners.push(handler)
    return () => { listeners = listeners.filter((l) => l !== handler) }
  }, [])

  useEffect(() => {
    const threshold = NOISE_THRESHOLDS[pref.noiseLevel]
    let filtered = globalArticles.filter((a) => a.aiScore >= threshold)
    if (domain !== 'all') filtered = filtered.filter((a) => a.domain === domain)
    if (region !== 'all') filtered = filtered.filter((a) => a.region === region)
    // 雷达词命中的置顶
    const radar = filtered.filter((a) => a.radarWords?.some((w) => pref.radarWords.includes(w)))
    const rest = filtered.filter((a) => !a.radarWords?.some((w) => pref.radarWords.includes(w)))
    // 附加已读状态
    const withRead = [...radar, ...rest].map((a) => ({ ...a, isRead: readIds.has(a.id) }))
    setArticles(withRead)
  }, [domain, region, pref, readIds])

  const toggleLike = (id: number) => {
    globalArticles = globalArticles.map((a) =>
      a.id === id ? { ...a, isLiked: !a.isLiked, likeCount: a.isLiked ? a.likeCount - 1 : a.likeCount + 1 } : a
    )
    notify()
  }

  const toggleCollect = (id: number) => {
    globalArticles = globalArticles.map((a) =>
      a.id === id ? { ...a, isCollected: !a.isCollected, collectCount: a.isCollected ? a.collectCount - 1 : a.collectCount + 1 } : a
    )
    // 更新用户收藏数
    const collectedCount = globalArticles.filter((a) => a.isCollected).length
    globalUser = { ...globalUser, collectCount: collectedCount }
    notify()
  }

  const markRead = (id: number) => {
    if (!globalReadIds.has(id)) {
      globalReadIds = new Set(Array.from(globalReadIds).concat(id))
      const article = globalArticles.find((a) => a.id === id)
      if (article) {
        globalReadHistory = [article, ...globalReadHistory.filter((a) => a.id !== id)]
      }
      globalUser = { ...globalUser, readCount: globalReadIds.size }
      notify()
    }
  }

  return { articles, toggleLike, toggleCollect, markRead }
}

export function useReadHistory() {
  const [history, setHistory] = useState<Article[]>([...globalReadHistory])

  useEffect(() => {
    const handler = () => setHistory([...globalReadHistory])
    listeners.push(handler)
    return () => { listeners = listeners.filter((l) => l !== handler) }
  }, [])

  const clearHistory = () => {
    globalReadHistory = []
    globalReadIds = new Set()
    globalUser = { ...globalUser, readCount: 0 }
    notify()
  }

  return { history, clearHistory }
}

export function useArticle(id: number) {
  const [article, setArticle] = useState<Article | null>(globalArticles.find((a) => a.id === id) ?? null)

  useEffect(() => {
    const handler = () => setArticle(globalArticles.find((a) => a.id === id) ?? null)
    listeners.push(handler)
    return () => { listeners = listeners.filter((l) => l !== handler) }
  }, [id])

  const toggleLike = () => {
    if (!article) return
    globalArticles = globalArticles.map((a) =>
      a.id === id ? { ...a, isLiked: !a.isLiked, likeCount: a.isLiked ? a.likeCount - 1 : a.likeCount + 1 } : a
    )
    notify()
  }

  const toggleCollect = () => {
    if (!article) return
    globalArticles = globalArticles.map((a) =>
      a.id === id ? { ...a, isCollected: !a.isCollected, collectCount: a.isCollected ? a.collectCount - 1 : a.collectCount + 1 } : a
    )
    const collectedCount = globalArticles.filter((a) => a.isCollected).length
    globalUser = { ...globalUser, collectCount: collectedCount }
    notify()
  }

  // 进入文章时自动标记已读
  const markRead = () => {
    if (!globalReadIds.has(id)) {
      globalReadIds = new Set(Array.from(globalReadIds).concat(id))
      const a = globalArticles.find((x) => x.id === id)
      if (a) globalReadHistory = [a, ...globalReadHistory.filter((x) => x.id !== id)]
      globalUser = { ...globalUser, readCount: globalReadIds.size }
      notify()
    }
  }

  return { article, toggleLike, toggleCollect, markRead }
}

export function useUser() {
  const [user, setUser] = useState(globalUser)
  const [isLoggedIn, setIsLoggedIn] = useState(globalIsLoggedIn)
  const [hasOnboarded, setHasOnboarded] = useState(globalHasOnboarded)

  useEffect(() => {
    const handler = () => {
      setHasOnboarded(globalHasOnboarded)
      setIsLoggedIn(globalIsLoggedIn)
      setUser({ ...globalUser })
    }
    listeners.push(handler)
    return () => { listeners = listeners.filter((l) => l !== handler) }
  }, [])

  const login = (nickname: string) => {
    globalUser = { ...globalUser, nickname }
    globalIsLoggedIn = true
    localStorage.setItem('pulseread_logged_in', '1')
    notify()
  }

  const logout = () => {
    globalIsLoggedIn = false
    localStorage.removeItem('pulseread_logged_in')
    notify()
  }

  const completeOnboarding = () => {
    globalHasOnboarded = true
    localStorage.setItem('pulseread_onboarded', '1')
    notify()
  }

  return { user, isLoggedIn, hasOnboarded, login, logout, completeOnboarding }
}
