export type DomainType = 'tech' | 'finance' | 'policy' | 'commerce'
export type RegionType = 'all' | 'domestic' | 'international'
export type NoiseLevel = 'open' | 'focus' | 'major' | 'quake'
export type SentimentType = 'positive' | 'negative' | 'neutral'

export interface DomainConfig {
  key: DomainType
  label: string
  icon: string
  description: string
  color: string
  bgColor: string
  textColor: string
}

export interface NoiseLevelConfig {
  key: NoiseLevel
  label: string
  icon: string
  description: string
  scoreThreshold: number
  dailyCount: string
  recommended?: boolean
}

export interface Article {
  id: number
  title: string
  summary: string
  content?: string
  contentEn?: string
  domain: DomainType
  region: RegionType
  source: string
  publishTime: string
  aiScore: number
  sentiment: SentimentType
  radarWords?: string[]
  tags?: string[]
  isAiTranslated?: boolean
  likeCount: number
  collectCount: number
  isLiked?: boolean
  isCollected?: boolean
  aiSummary?: string
  aiKeyPoints?: string[]
  aiQuestions?: string[]
  knowledgeTree?: KnowledgeNode[]
}

export interface KnowledgeNode {
  id: string
  title: string
  description: string
  date?: string
  children?: KnowledgeNode[]
}

export interface UserPreference {
  noiseLevel: NoiseLevel
  domains: DomainType[]
  radarWords: string[]
  enableAutoTranslate: boolean
  regionPref: RegionType
  blockedSentiments: string[]
}
